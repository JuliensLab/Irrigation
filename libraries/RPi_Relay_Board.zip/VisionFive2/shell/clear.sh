#! /bin/bash

echo 60 > /sys/class/gpio/unexport
echo 61 > /sys/class/gpio/unexport 
echo 44 > /sys/class/gpio/unexport
echo Pin release is complete
